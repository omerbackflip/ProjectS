import 'jest'
import { Application } from 'express'
import request from 'supertest'
import { Container } from "typedi";

import { App } from '../../src/app';

describe('Integration Test', () => {


});
