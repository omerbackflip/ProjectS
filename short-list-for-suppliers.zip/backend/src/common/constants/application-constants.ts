module.exports = {

    status:
        [
            "Processed",
            "Suspended",
            "Rejected",
            "Returned",
        ],

}