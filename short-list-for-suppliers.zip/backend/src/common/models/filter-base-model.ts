export class FilterBaseModel {
    page: number;
    limit: number;
    sortBy: string;
    sortOrder: string
}