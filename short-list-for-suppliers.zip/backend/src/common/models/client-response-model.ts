export class ClientResponseModel {
    hasErrors: boolean = false;
    status: number;
    statusText: string;
    result: any;
}