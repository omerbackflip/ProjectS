export class PagingModel {
    total: number;
    totalPages: number;
    pageNumber: number;
    pageSize: number;
    sortBy: string;
}