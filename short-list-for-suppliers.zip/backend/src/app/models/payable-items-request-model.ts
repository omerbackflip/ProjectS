import { FilterBaseModel } from '../../common/models/filter-base-model';
export class PayableItemsModel extends FilterBaseModel {
    file: File;
}