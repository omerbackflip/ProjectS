export class AuthLoginModel {
    username: string;
    password: string;
}