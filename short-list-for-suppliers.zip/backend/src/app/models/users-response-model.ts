export class UserResponseModel {
    users:
        [{
            firstName: string,
            lastName: string,
            userName: string,
            rootUser: string,
            createdAt: Date
        }]
}